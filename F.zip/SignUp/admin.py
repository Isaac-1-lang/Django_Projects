from django.contrib import admin
from .models import User


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'password','confirm_password','full_name')
    search_fields = ('username', 'email')
    list_filter = ('email',)
    #readonly_fields = ('password','confirm_password','full_name')


